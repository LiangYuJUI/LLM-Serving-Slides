Main file: main.tex
Compiler: pdfLaTeX
Compile twice for navigation.
Figures: 12 supplied Without-Caption PNGs plus original Figures 6 and 7 for Main results; unchanged pixels.
