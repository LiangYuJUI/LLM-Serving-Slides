Main file: main.tex
Compiler: pdfLaTeX
Compile twice for navigation.
Figures: supplied Helix/Without-Caption PNGs, unchanged.
