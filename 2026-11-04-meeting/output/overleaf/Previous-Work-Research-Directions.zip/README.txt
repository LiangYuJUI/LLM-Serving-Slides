Main file: main.tex
Compiler: pdfLaTeX
Compile twice. No external assets required.
