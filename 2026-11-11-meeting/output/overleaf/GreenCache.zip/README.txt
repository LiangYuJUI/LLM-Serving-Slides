Main file: main.tex
Compiler: pdfLaTeX
Compile twice for navigation.
Figures: original vector crops from the SIGMETRICS 2026 paper.
