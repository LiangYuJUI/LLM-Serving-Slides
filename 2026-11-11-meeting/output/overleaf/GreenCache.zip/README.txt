Main file: main.tex
Compiler: pdfLaTeX
Compile twice for navigation.
Figures: 20 supplied Without-Caption PNGs. Pixels are unchanged.
