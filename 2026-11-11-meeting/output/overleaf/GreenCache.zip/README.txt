Main file: main.tex
Compiler: pdfLaTeX
Compile twice for navigation.
Figures: 20 supplied With-Caption PNGs. Pixels are unchanged.
