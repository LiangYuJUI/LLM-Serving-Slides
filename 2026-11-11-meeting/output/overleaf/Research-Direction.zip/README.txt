Main document: main.tex
Compiler: pdfLaTeX
Compile twice. Unnumbered cover plus six content slides. No external assets.
