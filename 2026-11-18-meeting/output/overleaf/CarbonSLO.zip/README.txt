Main file: main.tex
Compiler: pdfLaTeX
Compile twice for navigation.
Figures: supplied With-Caption and Without-Caption PNGs, plus pixel-subset crops.
Original PNGs are not redrawn.
