Main file: main.tex
Compiler: pdfLaTeX
Compile twice for numbering and navigation.
Self-contained Beamer source and original Helix Figure 3; 22 pages.
