Main file: main.tex
Compiler: pdfLaTeX
Compile twice for numbering and navigation.
Self-contained Beamer source, original Helix Figure 3, and ThunderServe Figure 5 (printed caption removed); 20 pages.
