Main file: main.tex
Compiler: pdfLaTeX
Compile twice for numbering and navigation.
26-page deck; all original figures required by the main and Previous Work backup slides are included.
