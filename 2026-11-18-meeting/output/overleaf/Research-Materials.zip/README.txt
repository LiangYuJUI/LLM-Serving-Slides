Main file: main.tex
Compiler: pdfLaTeX
Compile twice for numbering and navigation.
20-page deck with Helix Figure 3 and ThunderServe Figure 5.
