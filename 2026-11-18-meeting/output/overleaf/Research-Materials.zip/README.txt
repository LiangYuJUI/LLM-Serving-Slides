Main file: main.tex
Compiler: pdfLaTeX
Compile twice for numbering and navigation.
Self-contained Beamer source; 17 pages.
