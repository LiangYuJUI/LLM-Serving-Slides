Main file: main.tex
Compiler: pdfLaTeX
Compile twice for numbering and navigation.
Self-contained Beamer source; 22 pages.
