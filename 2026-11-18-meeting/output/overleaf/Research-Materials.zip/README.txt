Main file: main.tex
Compiler: pdfLaTeX
Compile twice for numbering and navigation.
Original Carbon--SLO Fig. 2 included unchanged.
