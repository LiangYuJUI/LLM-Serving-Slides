Compile main.tex twice with pdfLaTeX. Source: https://arxiv.org/abs/2608.11668v4
Figures are direct paper crops. Figure 10 contains panel (a) only.
