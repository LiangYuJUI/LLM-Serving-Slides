Tessera - Figures 1-11 with complete original captions

Source: Arxiv26_Tessera.pdf
Format: PNG, 600 dpi, rendered from the original PDF using PDFium.
Each PNG includes the entire figure, all subplots, legends, labels, and the complete original figure caption.
Original figure and caption typography/layout is preserved; no OCR, retyping, or redrawing.
Three-point safety margins are retained around the crop.

Figure 01 | PDF page 2 | Tessera_Figure_01_Kernel_Disaggregation.png
Figure 02 | PDF page 3 | Tessera_Figure_02_Kernel_Heterogeneity.png
Figure 03 | PDF page 4 | Tessera_Figure_03_Kernel_Duration_Ratios.png
Figure 04 | PDF page 4 | Tessera_Figure_04_System_Overview.png
Figure 05 | PDF page 6 | Tessera_Figure_05_GPU_Worker_Execution.png
Figure 06 | PDF page 8 | Tessera_Figure_06_Offline_Throughput.png
Figure 07 | PDF page 9 | Tessera_Figure_07_Online_Latency.png
Figure 08 | PDF page 9 | Tessera_Figure_08_Cluster_Scale_Throughput.png
Figure 09 | PDF page 10 | Tessera_Figure_09_Pipeline_Effectiveness.png
Figure 10 | PDF page 10 | Tessera_Figure_10_Online_Monitor_Sensitivity.png
Figure 11 | PDF page 10 | Tessera_Figure_11_Network_Bandwidth_and_MILP.png
