Entry point: main.tex
Compiler: pdfLaTeX
Compile twice for page numbering.
All required figure files are included.
