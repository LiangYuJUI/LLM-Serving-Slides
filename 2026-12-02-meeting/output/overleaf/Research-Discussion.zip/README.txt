Entry point: main.tex
Compiler: pdfLaTeX
Compile twice for final cross-references.
All required relative-path assets are included.
