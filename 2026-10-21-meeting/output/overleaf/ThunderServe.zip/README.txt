ThunderServe standalone presentation (36 pages)

Main LaTeX document: 2026-10-21-ThunderServe.tex
Compiler: pdfLaTeX
Keep the ThunderServe/ folder alongside the .tex file.
The ZIP contains the standalone source, all referenced figures and Chinese speaker notes.
Speaker notes explain the page mapping to the combined deck.
The combined source is retained separately in the original workspace.
Changes to standalone and combined sources are independent.
