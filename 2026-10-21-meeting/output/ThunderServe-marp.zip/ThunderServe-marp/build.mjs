import { readFile, writeFile, unlink } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const dir = path.dirname(fileURLToPath(import.meta.url));
const source = path.join(dir, '2026-10-21-ThunderServe.md');
const output = path.join(dir, 'ThunderServe.html');
const temp = path.join(dir, '.thunderserve-with-notes.md');
let markdown = await readFile(source, 'utf8');
let notes;
for (const candidate of ['../ThunderServe_scripts.md', 'ThunderServe_scripts.md']) {
  try { notes = await readFile(path.join(dir, candidate), 'utf8'); break; } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
}
const byPage = new Map();
if (notes) {
  for (const match of notes.matchAll(/^## 第 (\d+) 頁｜[^\n]+\n([\s\S]*?)(?=^## 第 |$(?![\s\S]))/gm)) {
    byPage.set(Number(match[1]), match[2].trim());
  }
}
byPage.set(36, '以上是 ThunderServe，接下來歡迎討論它的部署、排程與 KV transfer 設計。');
markdown = markdown.replace(/<!-- SLIDE (\d+) -->/g, (_, n) => {
  const text = byPage.get(Number(n));
  return text ? `<!--\n${text.replaceAll('-->', '→')}\n-->` : '';
});
try {
  await writeFile(temp, markdown);
  execFileSync(process.execPath, [path.join(dir, 'node_modules/@marp-team/marp-cli/marp-cli.js'), temp, '--html', '-o', output], { cwd: dir, stdio: 'inherit' });
  let html = await readFile(output, 'utf8');
  const images = [...html.matchAll(/src="(assets\/[^"<>]+)"/g)];
  for (const [, image] of images) {
    const data = await readFile(path.join(dir, image));
    html = html.replaceAll(`src="${image}"`, `src="data:image/png;base64,${data.toString('base64')}"`);
  }
  await writeFile(output, html);
  console.log(`Built ThunderServe.html: 36 slides, ${images.length} embedded images, ${byPage.size} speaker notes.`);
} finally {
  await unlink(temp).catch(() => {});
}
