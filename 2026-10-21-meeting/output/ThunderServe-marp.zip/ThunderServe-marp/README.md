# ThunderServe：Marp 試用版

這是 `2026-10-21-ThunderServe.tex` 的 36 頁 Markdown 版本。保留原頁序、圖表、公式、數據及 Algorithm 1；以 HTML/CSS 重建雙欄與配色，字體和行距與 Beamer 略有不同。原 LaTeX 檔沒有修改。

## 先看效果

直接用 Chrome 開啟 `ThunderServe.html` 即可，無須安裝 LaTeX、Node.js 或 Marp，也不需要網路。圖片、數學公式與播放器已包含在 HTML 裡，可單獨複製到其他電腦。

- 左右方向鍵：換頁。
- `P`：開啟 presenter view，顯示中文講稿；瀏覽器需允許這個視窗開啟。
- `O`：投影片總覽。
- 底部工具列：換頁、全螢幕、總覽及 presenter view。

`ThunderServe-marp.pdf` 是另外匯出的靜態版，方便和原本 Beamer PDF 比較。

## 修改內容

編輯 `2026-10-21-ThunderServe.md`：

- `---` 分隔投影片；最前面的 YAML 區塊則是設定，不是第一頁。
- `#` 是頁面標題；`-` 是條列；`>` 是底部重點框。
- `$...$`／`$$...$$` 分別是行內／獨立公式，採 MathJax。
- 圖片放在 `assets/`，使用相對路徑引用。
- `<div class="columns">` 等少量 HTML 用於雙欄排版；樣式集中在檔案開頭的 `style:`。
- `<!-- _class: ... -->` 設定單頁版型。
- `<!-- SLIDE 12 -->` 等標記讓 build script 對應既有中文講稿。

在 VS Code／相容編輯器安裝 **Marp for VS Code** 後，可以預覽 Markdown 簡報。此版本用到 HTML 排版，請在擴充功能設定中允許此檔案的 HTML。純 Markdown 預覽不一定會呈現簡報版型。

Markdown 和 LaTeX 是獨立版本；修改其中一份，不會自動同步到另一份。新增或刪除頁面時，也要調整頁面標記與講稿對照。

## 重新產生 HTML

只有編輯後重新匯出時才需要 Node.js 與 Marp，播放現成 HTML 不需要。於這個 `marp` 資料夾執行：

```sh
npm ci
npm run build
```

目前工作區已安裝依賴，之後只需 `npm run build`。依賴版本鎖定在 `package-lock.json`。

`build.mjs` 會讀取上層的 `ThunderServe_scripts.md`，把第 01–35 頁講稿放進 HTML presenter notes，再補上第 36 頁 Q&A。若使用獨立 ZIP，會改讀同資料夾的講稿。講稿沒有重複塞進投影片 Markdown，方便持續使用原講稿編輯。

輸出的 HTML 包含講稿，所以分享這份檔案也會一起分享 notes。更新講稿後，同樣執行 `npm run build` 即可更新 HTML。

## 匯出 PDF（選用）

需要已安裝 Chrome、Edge 或 Firefox；不需要 LaTeX compiler：

```sh
npm run pdf
```

本指令輸出投影片，不包含中文講稿。首次安裝依賴需要網路，之後用本機依賴匯出。

## 容量比較

本次轉換的 Markdown 約 35 KB，原 `.tex` 約 39 KB；含圖片、播放器、公式及講稿的獨立 HTML 約 2.6 MB。Markdown 主要省下標記文字，整體容量仍由圖片與輸出格式主導，PDF 也不保證比較小。

官方文件：[Marp CLI](https://github.com/marp-team/marp-cli)、[Marp for VS Code](https://github.com/marp-team/marp-vscode)。
